import logo from './logo.svg';
import './App.css';
import Header from './components/header/Header';

function App() {
  return (
    <div >
      <Header/>
    </div>
  );
}

export default App;
